-- MySQL dump 10.13  Distrib 8.0.34, for Win64 (x86_64)
--
-- Host: database-sun.cj5qzxjavwdo.ap-northeast-2.rds.amazonaws.com    Database: petpermint
-- ------------------------------------------------------
-- Server version	8.0.33

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
SET @MYSQLDUMP_TEMP_LOG_BIN = @@SESSION.SQL_LOG_BIN;
SET @@SESSION.SQL_LOG_BIN= 0;

--
-- GTID state at the beginning of the backup 
--

SET @@GLOBAL.GTID_PURGED=/*!80000 '+'*/ '';

--
-- Table structure for table `Animal`
--

DROP TABLE IF EXISTS `Animal`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `Animal` (
  `animalId` int NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `picture` varchar(500) DEFAULT NULL,
  `specie` varchar(100) NOT NULL,
  `age` varchar(10) NOT NULL,
  `note` varchar(1000) DEFAULT NULL,
  `weight` varchar(10) NOT NULL,
  `gender` varchar(10) NOT NULL,
  `isDelete` int NOT NULL DEFAULT '0',
  `userId` varchar(100) NOT NULL,
  PRIMARY KEY (`animalId`),
  KEY `fk_animal_user1_idx` (`userId`),
  CONSTRAINT `fk_animal_user1` FOREIGN KEY (`userId`) REFERENCES `User` (`userId`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Animal`
--

LOCK TABLES `Animal` WRITE;
/*!40000 ALTER TABLE `Animal` DISABLE KEYS */;
INSERT INTO `Animal` VALUES (0,'','','','','','','',0,'sky500ro@naver.com'),(7,'초롱','https://image.van-go.co.kr/place_main/2022/04/04/12217/035e1737735049018a2ed2964dda596c_750S.jpg','갱얼쥐','1살','초롱초롱초롱이','5kg','암컷',0,'alswl9703@naver.com'),(8,'금동','https://primary-sun-bucket.s3.ap-northeast-2.amazonaws.com/Petpermint/profile/alswl9703%40naver.com/pet/8.jpg','강아지','2살','null','4kg','수컷',0,'alswl9703@naver.com'),(9,'루이','https://www.prfish.com/shop/data/goods/1609236061793m0.jpg','물고기','3살',NULL,'0.2kg','암컷',0,'alswl9703@naver.com'),(10,'솔이','https://image.dongascience.com/Photo/2022/06/6982fdc1054c503af88bdefeeb7c8fa8.jpg','강아지','4살',NULL,'3kg','수컷',0,'alswl9703@naver.com'),(11,'코코','https://post-phinf.pstatic.net/MjAxOTAxMzFfMjYg/MDAxNTQ4OTE4NzkyMjU2.l1s9ZFcfvfotAMmISSKnRYz2NFZNTlLsYAN_Yl22DjQg.45z-gKvTMkJ0kuH9iDivwVDXLmwKiqIQNvM7kSzI-H0g.PNG/IoCQMks4PwYv2rg_79nP2_f4x0qg.jpg?type=w400','돼지','5살','null','15kg','암컷',0,'alswl9703@naver.com'),(14,'머루','https://primary-sun-bucket.s3.ap-northeast-2.amazonaws.com/Petpermint/profile/sky500ro%40gmail.com/pet/0.PNG','고양이','3살','맨날 도망감','5kg','수컷',0,'sky500ro@gmail.com'),(15,'오복','https://primary-sun-bucket.s3.ap-northeast-2.amazonaws.com/Petpermint/profile/sky500ro%40gmail.com/pet/0.PNG','고양이','4살','턱시도 고양이','4kg','암컷',0,'sky500ro@gmail.com');
/*!40000 ALTER TABLE `Animal` ENABLE KEYS */;
UNLOCK TABLES;
SET @@SESSION.SQL_LOG_BIN = @MYSQLDUMP_TEMP_LOG_BIN;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-02-14 17:34:38
