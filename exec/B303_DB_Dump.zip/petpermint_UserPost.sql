-- MySQL dump 10.13  Distrib 8.0.34, for Win64 (x86_64)
--
-- Host: database-sun.cj5qzxjavwdo.ap-northeast-2.rds.amazonaws.com    Database: petpermint
-- ------------------------------------------------------
-- Server version	8.0.33

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
SET @MYSQLDUMP_TEMP_LOG_BIN = @@SESSION.SQL_LOG_BIN;
SET @@SESSION.SQL_LOG_BIN= 0;

--
-- GTID state at the beginning of the backup 
--

SET @@GLOBAL.GTID_PURGED=/*!80000 '+'*/ '';

--
-- Table structure for table `UserPost`
--

DROP TABLE IF EXISTS `UserPost`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `UserPost` (
  `postId` int NOT NULL AUTO_INCREMENT,
  `hits` int NOT NULL DEFAULT '0',
  `content` varchar(1000) NOT NULL,
  `likes` int NOT NULL DEFAULT '0',
  `registTime` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `isDelete` tinyint NOT NULL DEFAULT '0',
  `userId` varchar(100) NOT NULL,
  PRIMARY KEY (`postId`),
  KEY `fk_userpost_user1_idx` (`userId`),
  CONSTRAINT `fk_userpost_user1` FOREIGN KEY (`userId`) REFERENCES `User` (`userId`)
) ENGINE=InnoDB AUTO_INCREMENT=135 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `UserPost`
--

LOCK TABLES `UserPost` WRITE;
/*!40000 ALTER TABLE `UserPost` DISABLE KEYS */;
INSERT INTO `UserPost` VALUES (123,0,'여러분! 새해 잘 보내셨나요? 날씨가 추워도 환기 잘 하시고 강아지 산책 잊지 마세요!',0,'2024-02-13 07:10:22',0,'gragasolaf@gmail.com'),(124,0,'강아지를 건강하게 키우기 위해서는 몇 가지 중요한 것들이 있습니다! \r\n먼저, 올바른 식이가 필요합니다. 고품질의 사료를 선택하고 적절한 양으로 먹여주세요. \r\n물론, 강아지에게는 주인의 애정과 관심도 필요합니다. 일상 속에서 간단한 애정 표현으로 더 행복한 동반자를 만들어보세요.',0,'2024-02-13 07:18:12',0,'gragasolaf@gmail.com'),(125,0,'간단한 산책, 즐거운 놀이, 그리고 따뜻한 관심으로 강아지와 함께하는 행복한 일상을 만들어보세요. 정기적인 건강 체크와 예방접종은 덤으로 건강도 지켜줄 거에요.',0,'2024-02-13 07:26:56',0,'gragasolaf@gmail.com'),(126,0,'매일의 짧은 산책과 간단한 훈련으로 강아지를 행복하게 유지하세요. 주인의 관심과 사랑은 건강한 강아지를 만들어냅니다.',0,'2024-02-13 07:30:06',0,'gragasolaf@gmail.com'),(127,0,'고양이와의 소중한 순간을 만들려면 정기적인 놀이와 부드러운 쓰다듬음이 필요합니다. 고양이의 식이와 건강을 고려한 관리는 행복한 고양이 생활의 핵심입니다. 매 순간을 공유하며 고양이와의 특별한 유대감을 느껴보세요.',0,'2024-02-13 07:31:37',0,'gragasolaf@gmail.com'),(128,0,'고양이와 함께하는 특별한 일상을 만들려면 부드러운 쓰다듬음과 다양한 장난감으로 놀이 시간을 확보하세요. 꾸준한 예방접종과 깨끗한 환경에서의 생활로 건강을 지켜보세요. 이렇게 하면 고양이와의 특별한 유대감이 더욱 깊어질 것입니다.',0,'2024-02-13 07:44:38',0,'gragasolaf@gmail.com'),(129,0,'고양이를 행복하게 키우려면 꾸준한 놀이와 안락한 공간을 제공하세요. 정기적인 건강 체크와 깨끗한 환경은 건강한 고양이 생활의 기초입니다. 주인의 사랑과 관심을 느끼며 고양이와의 특별한 순간을 즐겨보세요.',0,'2024-02-13 07:56:13',0,'gragasolaf@gmail.com'),(130,0,'모든 동물은 주인의 관심과 배려를 필요로 합니다. 산책, 놀이, 그리고 정기적인 건강 체크로 동물과의 특별한 연결을 즐겨보세요. 각 동물의 특성에 맞는 사랑과 관심으로 행복한 일상을 만들어나갈 수 있습니다.',0,'2024-02-13 08:06:46',0,'gragasolaf@gmail.com'),(131,0,'강아지, 고양이, 혹은 작은 햄스터까지, 각 동물은 특별한 관리와 사랑을 필요로 합니다. 각 동물의 성격을 존중하며, 놀이와 다양한 활동을 통해 동물 친구들과 함께하는 특별한 순간을 만들어보세요.',0,'2024-02-13 08:07:54',0,'gragasolaf@gmail.com'),(132,0,'반려견 저온 화상에 대해 알아봐요!\r\n\r\nhttps://morenature.co.kr/article/%ED%8E%AB%EB%8B%A5%ED%84%B0/19/96383/',1,'2024-02-13 08:11:54',0,'h53556927@gmail.com'),(133,0,'안녕하세요!',1,'2024-02-13 13:39:18',1,'alswl9703@naver.com'),(134,0,'안녕하세요!',0,'2024-02-14 01:43:38',0,'sky500ro@gmail.com');
/*!40000 ALTER TABLE `UserPost` ENABLE KEYS */;
UNLOCK TABLES;
SET @@SESSION.SQL_LOG_BIN = @MYSQLDUMP_TEMP_LOG_BIN;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-02-14 17:34:42
