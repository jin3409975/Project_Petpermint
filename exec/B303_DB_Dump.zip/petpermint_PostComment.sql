-- MySQL dump 10.13  Distrib 8.0.34, for Win64 (x86_64)
--
-- Host: database-sun.cj5qzxjavwdo.ap-northeast-2.rds.amazonaws.com    Database: petpermint
-- ------------------------------------------------------
-- Server version	8.0.33

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
SET @MYSQLDUMP_TEMP_LOG_BIN = @@SESSION.SQL_LOG_BIN;
SET @@SESSION.SQL_LOG_BIN= 0;

--
-- GTID state at the beginning of the backup 
--

SET @@GLOBAL.GTID_PURGED=/*!80000 '+'*/ '';

--
-- Table structure for table `PostComment`
--

DROP TABLE IF EXISTS `PostComment`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `PostComment` (
  `commentNo` int NOT NULL AUTO_INCREMENT,
  `content` varchar(1000) NOT NULL,
  `registTime` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `postId` int NOT NULL,
  `userId` varchar(100) NOT NULL,
  `isDelete` tinyint NOT NULL DEFAULT '0',
  PRIMARY KEY (`commentNo`),
  KEY `fk_postcomment_userpost1_idx` (`postId`),
  KEY `fk_postcomment_user_idx` (`userId`),
  CONSTRAINT `fk_postcomment_user` FOREIGN KEY (`userId`) REFERENCES `User` (`userId`),
  CONSTRAINT `fk_postcomment_userpost1` FOREIGN KEY (`postId`) REFERENCES `UserPost` (`postId`)
) ENGINE=InnoDB AUTO_INCREMENT=50 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `PostComment`
--

LOCK TABLES `PostComment` WRITE;
/*!40000 ALTER TABLE `PostComment` DISABLE KEYS */;
INSERT INTO `PostComment` VALUES (41,'물론, 활발한 운동이 필수입니다. 정기적인 산책과 놀이로 강아지의 체력을 유지하고 스트레스를 해소해주세요.','2024-02-13 07:24:33',124,'gragasolaf@gmail.com',0),(42,'부탁드려요!','2024-02-13 07:27:16',125,'gragasolaf@gmail.com',0),(43,'와!','2024-02-13 13:39:59',132,'alswl9703@naver.com',0),(44,'우와! 정보 고맙습니다!','2024-02-13 14:27:53',132,'ssafyjam@gmail.com',0),(45,'반갑습니다!','2024-02-13 14:36:48',133,'ssafyjam@gmail.com',1),(46,'좋은 말씀 감사합니다. 늘 잘 읽고 있읍니다.','2024-02-13 14:45:39',130,'ssafyjam@gmail.com',0),(47,'올 한해도 좋은 일만 깃들길 바랍니다.','2024-02-13 14:50:25',123,'ssafyjam@gmail.com',0),(48,'네 우리 견주들도 더불어 건강해지겠네요!','2024-02-13 14:52:34',124,'ssafyjam@gmail.com',0),(49,'감사해요!','2024-02-14 01:24:04',132,'gragasolaf@gmail.com',0);
/*!40000 ALTER TABLE `PostComment` ENABLE KEYS */;
UNLOCK TABLES;
SET @@SESSION.SQL_LOG_BIN = @MYSQLDUMP_TEMP_LOG_BIN;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-02-14 17:34:37
