-- MySQL dump 10.13  Distrib 8.0.34, for Win64 (x86_64)
--
-- Host: database-sun.cj5qzxjavwdo.ap-northeast-2.rds.amazonaws.com    Database: petpermint
-- ------------------------------------------------------
-- Server version	8.0.33

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
SET @MYSQLDUMP_TEMP_LOG_BIN = @@SESSION.SQL_LOG_BIN;
SET @@SESSION.SQL_LOG_BIN= 0;

--
-- GTID state at the beginning of the backup 
--

SET @@GLOBAL.GTID_PURGED=/*!80000 '+'*/ '';

--
-- Table structure for table `Reservation`
--

DROP TABLE IF EXISTS `Reservation`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `Reservation` (
  `appointId` int NOT NULL AUTO_INCREMENT,
  `time` varchar(100) NOT NULL DEFAULT '0',
  `diagnosis` varchar(1000) DEFAULT NULL,
  `note` varchar(1000) DEFAULT NULL,
  `type` int NOT NULL,
  `isDelete` int NOT NULL DEFAULT '0',
  `userId` varchar(100) NOT NULL,
  `licenseNumber` varchar(20) DEFAULT NULL,
  `hospitalNo` int DEFAULT NULL,
  `animalId` int DEFAULT NULL,
  PRIMARY KEY (`appointId`),
  KEY `fk_reservation_user1_idx` (`userId`),
  KEY `fk_reservation_expertuser1_idx` (`licenseNumber`),
  KEY `fk_reservation_animal_idx` (`animalId`),
  KEY `fk_reservation_hospitaldata_idx` (`hospitalNo`),
  CONSTRAINT `fk_reservation_animal` FOREIGN KEY (`animalId`) REFERENCES `Animal` (`animalId`),
  CONSTRAINT `fk_reservation_expertuser1` FOREIGN KEY (`licenseNumber`) REFERENCES `ExpertUser` (`licenseNumber`),
  CONSTRAINT `fk_reservation_user1` FOREIGN KEY (`userId`) REFERENCES `User` (`userId`),
  CONSTRAINT `fk_reservation_venuedata` FOREIGN KEY (`hospitalNo`) REFERENCES `VenueData` (`dataNo`)
) ENGINE=InnoDB AUTO_INCREMENT=222 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Reservation`
--

LOCK TABLES `Reservation` WRITE;
/*!40000 ALTER TABLE `Reservation` DISABLE KEYS */;
INSERT INTO `Reservation` VALUES (138,'2024-02-08 10:00',NULL,'아파요',2,0,'alswl9703@naver.com',NULL,46,7),(150,'2024-02-08 13:00',NULL,NULL,3,0,'alswl9703@naver.com',NULL,12959,0),(151,'2024-02-08 13:00',NULL,NULL,3,0,'alswl9703@naver.com',NULL,12959,0),(152,'2024-02-08 13:00',NULL,NULL,3,0,'alswl9703@naver.com',NULL,12959,0),(153,'2024-02-08 13:00',NULL,NULL,3,0,'alswl9703@naver.com',NULL,12959,0),(154,'2024-02-08 13:00',NULL,NULL,3,0,'sky500ro@naver.com',NULL,20818,0),(155,'2024-02-09 11:00',NULL,NULL,3,0,'sky500ro@naver.com',NULL,20818,0),(156,'2024-02-08 14:00',NULL,NULL,3,0,'sky500ro@naver.com',NULL,20818,0),(157,'2024-02-08 14:00',NULL,NULL,3,0,'ssafyjam@gmail.com',NULL,4616,0),(159,'2024-02-02 00:00',NULL,'',2,0,'alswl9703@naver.com',NULL,20,0),(160,'2024-02-16 13:00',NULL,'',2,0,'alswl9703@naver.com',NULL,20,7),(165,'2024-02-11 13:00',NULL,'금동이 너무 통통해요',2,0,'alswl9703@naver.com',NULL,26,8),(166,'2024-02-04 14:00',NULL,NULL,3,0,'alswl9703@naver.com',NULL,7521,0),(167,'2024-02-04 15:00',NULL,NULL,3,0,'alswl9703@naver.com',NULL,18736,0),(168,'2024-02-04 16:00',NULL,NULL,3,0,'alswl9703@naver.com',NULL,7521,0),(169,'2024-02-04 16:00',NULL,NULL,3,0,'alswl9703@naver.com',NULL,12985,0),(170,'2024-02-04 16:00',NULL,NULL,3,0,'alswl9703@naver.com',NULL,12959,0),(171,'2024-02-11 16:24',NULL,NULL,3,0,'alswl9703@naver.com',NULL,4408,0),(172,'2024-02-11 16:28',NULL,NULL,3,0,'alswl9703@naver.com',NULL,4408,0),(182,'2024-02-15 10:00',NULL,'test',1,0,'alswl9703@naver.com','12345',0,11),(183,'2024-02-13 12:23',NULL,NULL,3,0,'h53556927@gmail.com',NULL,19486,0),(184,'2024-02-13 12:23',NULL,NULL,3,0,'h53556927@gmail.com',NULL,19486,0),(185,'2024-02-13 14:11',NULL,NULL,3,0,'ssafyjam@gmail.com',NULL,3265,0),(186,'2024-02-13 10:20',NULL,'특이사항',1,0,'ssafyjam@gmail.com','12345',0,0),(187,'2024-02-15 11:00',NULL,'test2',1,0,'alswl9703@naver.com','12345',0,7),(188,'2024-02-15 12:00',NULL,'test3',1,0,'alswl9703@naver.com','12345',0,10),(189,'2024-02-15 13:00',NULL,'test3',1,0,'alswl9703@naver.com','12345',0,8),(190,'2024-02-15 14:00',NULL,'test3',1,0,'alswl9703@naver.com','12345',0,9),(191,'2024-02-14 10:00',NULL,'아파요',1,0,'alswl9703@naver.com','12345',0,11),(192,'2024-02-13 22:38',NULL,NULL,3,0,'sky500ro@naver.com',NULL,7521,0),(193,'2024-02-15 10:00',NULL,'선생님 우리 아이가 너무 살이 쪘어요 ㅠ ',1,0,'ssafyjam@gmail.com','98426',0,0),(194,'2024-02-22 16:20',NULL,'건강 검진',2,0,'alswl9703@naver.com',NULL,27,8),(195,'2024-02-22 16:20',NULL,'건강 검진',2,0,'alswl9703@naver.com',NULL,9,10),(196,'2024-02-22 16:40',NULL,'건강 검진',2,0,'alswl9703@naver.com',NULL,9,10),(197,'2024-02-16 16:40',NULL,'예방 접종및 광견병 주사 접종',2,0,'alswl9703@naver.com',NULL,26,8),(200,'2024-02-14 10:43',NULL,NULL,3,0,'sky500ro@gmail.com',NULL,74,0),(201,'2024-02-14 11:00',NULL,NULL,3,0,'sky500ro@gmail.com',NULL,14226,0),(202,'2024-01-31 10:00',NULL,NULL,1,0,'sky500ro@gmail.com','12345',0,14),(203,'2024-01-31 21:00',NULL,NULL,1,0,'sky500ro@gmail.com','12345',0,14),(204,'2024-01-31 07:00',NULL,NULL,1,0,'sky500ro@gmail.com','12345',0,14),(205,'2024-01-29 13:00',NULL,NULL,1,0,'sky500ro@gmail.com','12345',0,14),(210,'2024-01-31 11:00',NULL,NULL,1,0,'sky500ro@gmail.com','12345',0,14),(211,'2024-01-29 17:00',NULL,NULL,1,0,'sky500ro@gmail.com','12345',0,14),(212,'2024-02-04 17:00',NULL,NULL,1,0,'sky500ro@gmail.com','12345',0,14),(213,'2024-02-07 12:00',NULL,NULL,1,0,'sky500ro@gmail.com','12345',0,14),(214,'2024-02-09 12:00',NULL,NULL,1,0,'sky500ro@gmail.com','12345',0,14),(215,'2024-02-11 18:00',NULL,NULL,1,0,'sky500ro@gmail.com','12345',0,14),(216,'2024-02-13 10:00',NULL,NULL,1,0,'sky500ro@gmail.com','12345',0,14),(217,'2024-02-12 14:00',NULL,NULL,2,0,'sky500ro@gmail.com',NULL,111,14),(218,'2024-02-19 15:00',NULL,NULL,2,0,'sky500ro@gmail.com',NULL,111,14),(219,'2024-02-09 15:00',NULL,NULL,2,0,'sky500ro@gmail.com',NULL,111,14),(220,'2024-02-03 17:00',NULL,NULL,2,0,'sky500ro@gmail.com',NULL,111,14),(221,'2024-01-31 11:00',NULL,NULL,2,0,'sky500ro@gmail.com',NULL,111,14);
/*!40000 ALTER TABLE `Reservation` ENABLE KEYS */;
UNLOCK TABLES;
SET @@SESSION.SQL_LOG_BIN = @MYSQLDUMP_TEMP_LOG_BIN;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-02-14 17:34:37
