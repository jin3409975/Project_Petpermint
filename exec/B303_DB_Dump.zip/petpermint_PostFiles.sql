-- MySQL dump 10.13  Distrib 8.0.34, for Win64 (x86_64)
--
-- Host: database-sun.cj5qzxjavwdo.ap-northeast-2.rds.amazonaws.com    Database: petpermint
-- ------------------------------------------------------
-- Server version	8.0.33

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
SET @MYSQLDUMP_TEMP_LOG_BIN = @@SESSION.SQL_LOG_BIN;
SET @@SESSION.SQL_LOG_BIN= 0;

--
-- GTID state at the beginning of the backup 
--

SET @@GLOBAL.GTID_PURGED=/*!80000 '+'*/ '';

--
-- Table structure for table `PostFiles`
--

DROP TABLE IF EXISTS `PostFiles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `PostFiles` (
  `url` varchar(1000) NOT NULL,
  `fileName` varchar(200) NOT NULL,
  `postId` int NOT NULL,
  KEY `fk_postfiles_userpost1_idx` (`postId`),
  CONSTRAINT `fk_postfiles_userpost1` FOREIGN KEY (`postId`) REFERENCES `UserPost` (`postId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `PostFiles`
--

LOCK TABLES `PostFiles` WRITE;
/*!40000 ALTER TABLE `PostFiles` DISABLE KEYS */;
INSERT INTO `PostFiles` VALUES ('https://primary-sun-bucket.s3.ap-northeast-2.amazonaws.com/Petpermint/img/123/0_%EC%83%88%ED%95%B4.jpg','0_새해.jpg',123),('https://primary-sun-bucket.s3.ap-northeast-2.amazonaws.com/Petpermint/img/124/0_dog.jpg','0_dog.jpg',124),('https://primary-sun-bucket.s3.ap-northeast-2.amazonaws.com/Petpermint/img/125/0_closeup_dog.jpg','0_closeup_dog.jpg',125),('https://primary-sun-bucket.s3.ap-northeast-2.amazonaws.com/Petpermint/img/126/0_%EC%82%B0%EC%B1%85.jpg','0_산책.jpg',126),('https://primary-sun-bucket.s3.ap-northeast-2.amazonaws.com/Petpermint/img/127/0_%EA%B3%A0%EC%96%91%EC%9D%B4.jpg','0_고양이.jpg',127),('https://primary-sun-bucket.s3.ap-northeast-2.amazonaws.com/Petpermint/img/128/0_%EA%B3%A0%EC%96%91%EC%9D%B4_2.jpg','0_고양이_2.jpg',128),('https://primary-sun-bucket.s3.ap-northeast-2.amazonaws.com/Petpermint/img/129/0_%EA%B3%A0%EC%96%91%EC%9D%B4%20%EB%86%80%EC%9D%B4.jpg','0_고양이 놀이.jpg',129),('https://primary-sun-bucket.s3.ap-northeast-2.amazonaws.com/Petpermint/img/130/0_squirrel.jpg','0_squirrel.jpg',130),('https://primary-sun-bucket.s3.ap-northeast-2.amazonaws.com/Petpermint/img/131/0_squirrel_2.jpg','0_squirrel_2.jpg',131),('https://primary-sun-bucket.s3.ap-northeast-2.amazonaws.com/Petpermint/img/132/0_%EB%B0%98%EB%A0%A4%EA%B2%AC%20%EC%A0%80%EC%98%A8%20%ED%99%94%EC%83%81.png','0_반려견 저온 화상.png',132);
/*!40000 ALTER TABLE `PostFiles` ENABLE KEYS */;
UNLOCK TABLES;
SET @@SESSION.SQL_LOG_BIN = @MYSQLDUMP_TEMP_LOG_BIN;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-02-14 17:34:43
