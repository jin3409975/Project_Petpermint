-- MySQL dump 10.13  Distrib 8.0.34, for Win64 (x86_64)
--
-- Host: database-sun.cj5qzxjavwdo.ap-northeast-2.rds.amazonaws.com    Database: petpermint
-- ------------------------------------------------------
-- Server version	8.0.33

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
SET @MYSQLDUMP_TEMP_LOG_BIN = @@SESSION.SQL_LOG_BIN;
SET @@SESSION.SQL_LOG_BIN= 0;

--
-- GTID state at the beginning of the backup 
--

SET @@GLOBAL.GTID_PURGED=/*!80000 '+'*/ '';

--
-- Table structure for table `User`
--

DROP TABLE IF EXISTS `User`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `User` (
  `userId` varchar(100) NOT NULL,
  `password` varchar(1000) NOT NULL,
  `userName` varchar(50) NOT NULL,
  `address` varchar(500) NOT NULL,
  `phone` varchar(20) NOT NULL,
  `type` int NOT NULL,
  `picture` varchar(500) DEFAULT NULL,
  `isDelete` int NOT NULL DEFAULT '0',
  PRIMARY KEY (`userId`),
  UNIQUE KEY `phone_UNIQUE` (`phone`),
  KEY `fk_user_verification_idx` (`userId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `User`
--

LOCK TABLES `User` WRITE;
/*!40000 ALTER TABLE `User` DISABLE KEYS */;
INSERT INTO `User` VALUES ('alswl9703@naver.com','$2a$10$Jr4UVKzZOoipY90kapIAjeRuOlsPc1xYBOAaUA5AH5/AVYwMDkV8S','김재민','서울 성동구 서울숲길 17','010-9999-9998',1,'https://primary-sun-bucket.s3.ap-northeast-2.amazonaws.com/Petpermint/profile/alswl9703%40naver.com/alswl9703%40naver.com.jpg',0),('chelimm.lee@gmail.com','$2a$10$C6ihoglNLCMfpdxSosb8TuXfEvbvN66M9vEjz9TljOzScOmt0JgEq','수의사지망생','null null','01011111111',2,'0',0),('da@gmail.com','$2a$10$UDo.ld26dBHvcggM8esaMePx32kkJfzpbVsJSnSGQjweiRz1VeZP6','이채은','서울 강남구 가로수길 5','010-9876-9874',2,'0',0),('ga@gmail.com','$2a$10$o4s4Hc.r4x53B6ZC1kyjwOVb7TdYr8nNvfUydATm.lwiZQc2gdpiq','김봉팔','서울 강남구 가로수길 5','010-9876-9876',2,'0',0),('ghjadmb21@gmail.com','$2a$10$eQDLoU9WN/xbtlYC/57UhuFsOe7e0Eg2P3r0jg9jilCoE2MNLbf7q','양꼬치','서울 강남구 테헤란로 212','01012341234',1,'0',0),('gragasolaf@gmail.com','$2a$10$6q4tlSPeNDh5TVaGqbq7R.zhKqeUNCyUYrszbKfttqUeEmJTvOZYa','장선웅','충북 충주시 노은면 가신원통길 32  ','010-9999-8765',2,'0',0),('h53556927@gmail.com','$2a$10$OHZWrMPXMF5h/ylx98B48uWy5miuNSVn4zuZQJq3TyBxENY8R7SaS','김싸피','대전 유성구 동서대로 98-39 207호','010-0000-1111',1,'0',0),('ma@gmail.com','$2a$10$ySgEZQ5hlhIG1CHsH7QTjOA44khane2gj3dywuMhg9CHFwbqSF53K','이지은','서울 강남구 가로수길 5','010-9876-9872',2,'0',0),('na@gmail.com','$2a$10$cUf5qqJFOOg36tVRxd1CVe2J6scFipas4WwkdUgUsr9sQmnEWhxha','이민지','서울 강남구 가로수길 5','010-9876-9875',2,'0',0),('openvidujam@gmail.com','$2a$10$mKcmuiw8R05Nng0ofmPaMOKMMF1Z2oK05MDpeC5R0VzhHe4DyE5qK','김재민','대전 동구 동대전로46번길 7 ㅁㄴㅇ','010-2122-7772',1,'0',0),('ra@gmail.com','$2a$10$O9uwG1c5S4vmaV5ieY34X.e4jCwoWaskqmK.8mHwJs3oswBEdWpxi','장선웅','서울 강남구 가로수길 5','010-9876-9873',2,'0',0),('sky500ro@gmail.com','$2a$10$0zyrqEeC2WGZOKMUkNjad.MTHvqDn18/csKcqCk3uy22nbfDxLFwq','이이수수형형','서울 강남구 가로수길 5','010-7458-9632',1,'0',0),('sky500ro@naver.com','$2a$10$IiqXZJuXlGfT.3lHeBD.HOjYTB45aOENmGcC1uhfm3ztNDGHOwAsu','이수형','충북 청주시 서원구 1순환로 627','010-4718-1248',2,NULL,0),('ssafyjam@gmail.com','$2a$10$8McC0ImoK.InN34IvzEzqOB8XvYcr0GCjkEinju0TCKDlbRcRHizm','김잼잼','대전 동구 동대전로248번길','01021227772',1,'0',0),('ssafyminjilee@gmail.com','$2a$10$bfbv/QKl5Yiu4XpQQb446.S.AO.QFo03JlIlVUlKbeVL862x0Td1S','이민지','충남 천안시 동남구 가마골1길 5 21','010-3573-5049',1,'0',0),('test@test.com','$2a$10$yfu7jBOYtHh.6Sj9.AG9q.RQxniDfdfrZNkEp8h8VYJFPvPqm8mcK','김재민','test','010-0000-0000',1,'0',0);
/*!40000 ALTER TABLE `User` ENABLE KEYS */;
UNLOCK TABLES;
SET @@SESSION.SQL_LOG_BIN = @MYSQLDUMP_TEMP_LOG_BIN;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-02-14 17:34:39
