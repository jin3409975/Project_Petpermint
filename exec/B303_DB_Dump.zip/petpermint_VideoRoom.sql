-- MySQL dump 10.13  Distrib 8.0.34, for Win64 (x86_64)
--
-- Host: database-sun.cj5qzxjavwdo.ap-northeast-2.rds.amazonaws.com    Database: petpermint
-- ------------------------------------------------------
-- Server version	8.0.33

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
SET @MYSQLDUMP_TEMP_LOG_BIN = @@SESSION.SQL_LOG_BIN;
SET @@SESSION.SQL_LOG_BIN= 0;

--
-- GTID state at the beginning of the backup 
--

SET @@GLOBAL.GTID_PURGED=/*!80000 '+'*/ '';

--
-- Table structure for table `VideoRoom`
--

DROP TABLE IF EXISTS `VideoRoom`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `VideoRoom` (
  `roomId` int NOT NULL AUTO_INCREMENT,
  `startTime` datetime NOT NULL,
  `roomName` varchar(100) NOT NULL,
  `note` varchar(1000) DEFAULT NULL,
  `isDelete` tinyint NOT NULL DEFAULT '0',
  `userId` varchar(100) NOT NULL,
  `sessionId` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`roomId`),
  KEY `fk_videoroom_user1_idx` (`userId`),
  CONSTRAINT `fk_videoroom_user1` FOREIGN KEY (`userId`) REFERENCES `User` (`userId`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `VideoRoom`
--

LOCK TABLES `VideoRoom` WRITE;
/*!40000 ALTER TABLE `VideoRoom` DISABLE KEYS */;
INSERT INTO `VideoRoom` VALUES (2,'2024-02-15 08:00:00','미용교실','미용교실입니다',0,'test@test.com',NULL),(3,'2024-02-10 20:00:00','강아지 산책 주기','산책주기에 관한 강의입니다',0,'test@test.com',NULL),(4,'2024-02-10 22:00:00','강아지 미용','강아지',0,'test@test.com',NULL),(5,'2024-02-13 22:00:00','판다 미용','판다 미용에 대한 모든 것',0,'test@test.com','ses_WOHGQKnAAy'),(6,'2024-02-11 22:00:00','고양이 미용','고양이',0,'test@test.com','ses_U4rlsBYNxZ'),(7,'2024-02-25 10:00:00','약제학','약제학 방송 ',0,'test@test.com','ses_AD39qbwLt3');
/*!40000 ALTER TABLE `VideoRoom` ENABLE KEYS */;
UNLOCK TABLES;
SET @@SESSION.SQL_LOG_BIN = @MYSQLDUMP_TEMP_LOG_BIN;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-02-14 17:34:38
