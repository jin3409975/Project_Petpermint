-- MySQL dump 10.13  Distrib 8.0.34, for Win64 (x86_64)
--
-- Host: database-sun.cj5qzxjavwdo.ap-northeast-2.rds.amazonaws.com    Database: petpermint
-- ------------------------------------------------------
-- Server version	8.0.33

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
SET @MYSQLDUMP_TEMP_LOG_BIN = @@SESSION.SQL_LOG_BIN;
SET @@SESSION.SQL_LOG_BIN= 0;

--
-- GTID state at the beginning of the backup 
--

SET @@GLOBAL.GTID_PURGED=/*!80000 '+'*/ '';

--
-- Table structure for table `ExpertUser`
--

DROP TABLE IF EXISTS `ExpertUser`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `ExpertUser` (
  `licenseNumber` varchar(20) NOT NULL,
  `note` varchar(1000) DEFAULT NULL,
  `startTime` varchar(50) DEFAULT '09:00',
  `endTime` varchar(50) DEFAULT '18:00',
  `userId` varchar(100) NOT NULL,
  `hospitalNo` int DEFAULT NULL,
  `hospitalName` varchar(300) DEFAULT NULL,
  PRIMARY KEY (`licenseNumber`),
  KEY `fk_expertuser_user1_idx` (`userId`),
  KEY `fk_expertuser_hospitaldata1_idx` (`hospitalNo`),
  CONSTRAINT `fk_expertuser_user1` FOREIGN KEY (`userId`) REFERENCES `User` (`userId`),
  CONSTRAINT `fk_experuser_hospitaldata` FOREIGN KEY (`hospitalNo`) REFERENCES `HospitalData` (`hospitalNo`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ExpertUser`
--

LOCK TABLES `ExpertUser` WRITE;
/*!40000 ALTER TABLE `ExpertUser` DISABLE KEYS */;
INSERT INTO `ExpertUser` VALUES ('11111','안녕하세요','09:00','18:00','ga@gmail.com',0,'가 동물병원'),('12312','','null','null','chelimm.lee@gmail.com',0,'대전 3반 동물병원'),('12345','05:00','10:00','20:00','sky500ro@naver.com',0,'싸피 동물병원'),('22222','안녕하세요','09:00','18:00','ra@gmail.com',0,'라 동물병원'),('33333','안녕하세요','09:00','18:00','da@gmail.com',0,'다 동물병원'),('44444','안녕하세요','09:00','18:00','na@gmail.com',0,'나 동물병원'),('55555','안녕하세요','09:00','18:00','ma@gmail.com',0,'마 동물병원'),('98426','ㅎㅇ','09:00','18:00','gragasolaf@gmail.com',0,'싸피병원');
/*!40000 ALTER TABLE `ExpertUser` ENABLE KEYS */;
UNLOCK TABLES;
SET @@SESSION.SQL_LOG_BIN = @MYSQLDUMP_TEMP_LOG_BIN;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-02-14 17:34:42
